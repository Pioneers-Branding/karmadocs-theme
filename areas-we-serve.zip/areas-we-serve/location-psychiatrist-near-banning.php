<?php
/*
Template Name: Location - Banning
*/
get_header();
?>
<main id="main" class="site-main" role="main">
﻿<!--
Suggested URL: /psychiatrist-near-banning/
SEO Title: Expert Psychiatrist Near Banning, CA | Karma Doctors & Associates
Meta Description: Searching for a top-rated psychiatrist near Banning, CA? Karma Doctors & Associates offers advanced mental health care, including TMS therapy and medication management. Visit us for compassionate, integrative psychiatric care in the Coachella Valley.
-->

<!-- BRAND ALIGNED ANIMATION & COLOR ENGINE -->
<style>
    :root {
        --brand-purple: #603177;
        --brand-purple-light: #7a4d8f;
        --brand-orange: #f48f12;
        --brand-dark: #1f2937;
        --brand-gray: #f9fafb;
    }

    @keyframes scrollFadeUp {
        from {
            opacity: 0;
            transform: translateY(40px);
        }

        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    @keyframes pulse {
        0% {
            transform: scale(0.95);
            box-shadow: 0 0 0 0 rgba(244, 143, 18, 0.7);
        }

        70% {
            transform: scale(1);
            box-shadow: 0 0 0 25px rgba(244, 143, 18, 0);
        }

        100% {
            transform: scale(0.95);
            box-shadow: 0 0 0 0 rgba(244, 143, 18, 0);
        }
    }

    .lux-animate {
        animation: scrollFadeUp 1s cubic-bezier(0.165, 0.84, 0.44, 1) forwards;
        opacity: 1;
    }

    .lux-hover-card {
        transition: all 0.5s cubic-bezier(0.23, 1, 0.32, 1);
        border: 1px solid rgba(0, 0, 0, 0.05);
    }

    .lux-hover-card:hover {
        transform: translateY(-15px);
        box-shadow: 0 40px 100px rgba(96, 49, 119, 0.1) !important;
        border-color: var(--brand-orange) !important;
    }

    /* FAQ Accordion Styles */
    .faq-grid {
        display: grid;
        grid-template-columns: 0.8fr 1.2fr;
        gap: 80px;
        align-items: start;
    }

    @media (max-width: 991px) {
        .faq-grid {
            grid-template-columns: 1fr;
            gap: 50px;
        }
    }

    .faq-item {
        margin-bottom: 20px;
        border-radius: 12px;
        overflow: hidden;
        background: #ffffff;
        border: 1px solid #F3F4F6;
        transition: all 0.3s ease;
    }

    .faq-item:hover {
        border-color: rgba(96, 49, 119, 0.2);
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
    }

    .faq-item summary {
        padding: 25px 30px;
        font-size: 18px;
        font-weight: 700;
        color: var(--brand-dark);
        cursor: pointer;
        list-style: none;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 20px;
        line-height: 1.4;
    }

    .faq-item summary::-webkit-details-marker {
        display: none;
    }

    .faq-item summary::after {
        content: '+';
        font-size: 24px;
        font-weight: 400;
        color: #9CA3AF;
        transition: transform 0.3s ease;
    }

    .faq-item[open] summary::after {
        content: '\2212';
        color: var(--brand-purple);
    }

    .faq-item[open] {
        background: rgba(96, 49, 119, 0.02);
        border-color: rgba(96, 49, 119, 0.1);
    }

    .faq-answer {
        padding: 0 30px 25px 30px;
        color: #6B7280;
        line-height: 1.8;
        font-size: 16px;
    }

    .faq-answer p {
        margin: 0;
    }
</style>

<!-- BRAND HERO: THE EVOLUTION OF CARE -->
<section
    style="padding: 160px 20px; background: linear-gradient(135deg, #1a0f3c 0%, var(--brand-purple) 100%), url('https://karmadocs.com/wp-content/uploads/2024/01/hero-bg-dark.jpg'); background-size: cover; background-position: center; background-blend-mode: overlay; color: white; text-align: center; position: relative; overflow: hidden; border-bottom: 6px solid var(--brand-orange);">
    <div style="max-width: 1100px; margin: 0 auto; position: relative; z-index: 10;">
        <div class="lux-animate"
            style="display: inline-block; background: rgba(244, 143, 18, 0.15); backdrop-filter: blur(15px); color: var(--brand-orange); padding: 12px 35px; border-radius: 100px; text-transform: uppercase; font-size: 14px; font-weight: 800; letter-spacing: 4px; margin-bottom: 40px; border: 1px solid rgba(244, 143, 18, 0.3);">
            <a href='https://karmadocs.com/' style='color: var(--brand-orange); text-decoration: none; font-weight: 700;'>Karma Doctors & Associates</a>
        </div>
        <h1 class='lux-animate' style='font-size: clamp(3.5rem, 8vw, 5.5rem); font-weight: 900; line-height: 0.95; margin-bottom: 40px; letter-spacing: -0.04em;'>Trusted Psychiatrist <br /> <span style="color: var(--brand-orange);">Near Banning</span></h1>
        <p class='lux-animate' style='font-size: 24px; color: rgba(255, 255, 255, 0.9); margin-bottom: 70px; line-height: 1.6; max-width: 850px; margin-left: auto; margin-right: auto; font-weight: 300;'>Elite mental healthcare is now local to Banning. We extend our proven Coachella Valley psychiatric excellence to serve you and your family.</p>
        <div class="lux-animate" style="display: flex; gap: 25px; justify-content: center; flex-wrap: wrap;">
            <a href="https://karmadocs.com/contact/"
                style="background: var(--brand-orange); color: white; padding: 25px 65px; border-radius: 100px; text-decoration: none; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; font-size: 15px; box-shadow: 0 20px 50px rgba(244, 143, 18, 0.4); transition: transform 0.3s ease;">
                Book Appointment
            </a>
            <a href="tel:9512978375"
                style="background: transparent; color: white; padding: 23px 60px; border-radius: 100px; text-decoration: none; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; font-size: 15px; border: 2px solid rgba(255, 255, 255, 0.4);">
                Call Specialist
            </a>
        </div>
    </div>
</section>

<!-- THE PROXIMITY & TRIPLE CLINIC MAP SECTION -->
<section style="padding: 120px 20px; background: #ffffff;">
    <div
        style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 80px; align-items: center;">
        <div class="lux-animate">
            <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 30px;">
                <div style="height: 2px; width: 60px; background: var(--brand-purple);"></div>
                <span
                    style="text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-purple);">Our
                    3 Prime Locations</span>
            </div>
            <h2 style='font-size: 46px; font-weight: 900; color: var(--brand-dark); line-height: 1.1; margin-bottom: 35px; letter-spacing: -0.02em;'>Premier Mental Health <br /> <span style='color: var(--brand-purple);'>For Banning Residents.</span></h2>
            <p style='font-size: 20px; line-height: 1.9; color: #4B5563; margin-bottom: 40px;'>We bridge the gap between innovation and accessibility in Banning, ensuring that the very best neurological care is just a short drive from your home.</p>

                        <!-- CLINIC DIRECTORY -->
            <div style="display: grid; gap: 20px;">
                <div
                    style="display: flex; align-items: start; gap: 15px; background: var(--brand-gray); padding: 20px; border-radius: 20px; border: 1px solid #E5E7EB; border-left: 5px solid var(--brand-orange);">
                    <div
                        style="background: var(--brand-orange); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">
                        1</div>
                    <div>
                        <h4 style="font-weight: 800; color: var(--brand-dark); font-size: 18px; margin-bottom: 5px;">
                            Palm Springs <span style="background: var(--brand-orange); color: white; font-size: 11px; padding: 2px 8px; border-radius: 10px; margin-left: 8px; font-weight: 800; text-transform: uppercase;">Closest Office</span></h4>
                        <p style="color: #6B7280; font-size: 14px;">560 S Paseo Dorotea, Suite 4-B, Palm Springs, CA 92264</p>
                    </div>
                </div>
                <div
                    style="display: flex; align-items: start; gap: 15px; background: var(--brand-gray); padding: 20px; border-radius: 20px; border: 1px solid #E5E7EB;">
                    <div
                        style="background: var(--brand-purple); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">
                        2</div>
                    <div>
                        <h4 style="font-weight: 800; color: var(--brand-dark); font-size: 18px; margin-bottom: 5px;">
                            Rancho Mirage</h4>
                        <p style="color: #6B7280; font-size: 14px;">35400 Bob Hope Dr. Suite 206, Rancho Mirage, CA 92270</p>
                    </div>
                </div>
                <div
                    style="display: flex; align-items: start; gap: 15px; background: var(--brand-gray); padding: 20px; border-radius: 20px; border: 1px solid #E5E7EB;">
                    <div
                        style="background: var(--brand-purple); color: white; width: 30px; height: 30px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-weight: 800; flex-shrink: 0;">
                        3</div>
                    <div>
                        <h4 style="font-weight: 800; color: var(--brand-dark); font-size: 18px; margin-bottom: 5px;">
                            Twentynine Palms</h4>
                        <p style="color: #6B7280; font-size: 14px;">72724 29 Palms Hwy. Suite 107, Twentynine Palms, CA 92277</p>
                    </div>
                </div>
            </div>
        </div>
        <!-- GOOGLE MAP -->
        <div
            style="height: 550px; border-radius: 30px; overflow: hidden; box-shadow: 0 20px 60px rgba(96, 49, 119, 0.12);">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3416.7118465902095!2d-116.53856102412097!3d33.80582967324902!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x80db1b58ab263901%3A0xa193fa021ad5815a!2s560%20S%20Paseo%20Dorotea%20%234b%2C%20Palm%20Springs%2C%20CA%2092264!5e0!3m2!1sen!2sus!4v1700000000000"
                width="100%" height="100%" style="border: 0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade">
            </iframe>
        </div>
    </div>
</section>
<!-- SERVICES GRID -->
<section style="padding: 120px 20px; background: var(--brand-gray);">
    <div style="max-width: 1000px; margin: 0 auto; text-align: center; margin-bottom: 80px;">
        <h2 style="font-size: 44px; font-weight: 900; color: var(--brand-dark); margin-bottom: 25px;">Conditions We
            Treat</h2>
        <div style="display: flex; align-items: center; justify-content: center; gap: 10px; margin-bottom: 25px;">
            <div style="height: 1px; width: 40px; background: #D1D5DB;"></div>
            <div style="transform: rotate(45deg); width: 10px; height: 10px; background: var(--brand-purple);"></div>
            <div style="height: 1px; width: 40px; background: #D1D5DB;"></div>
        </div>
        <p style="font-size: 20px; color: #4B5563; max-width: 800px; margin: 0 auto;">Utilizing advanced
            neuro-diagnostics to treat the biological root of mental health conditions.</p>
    </div>

    <div
        style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(340px, 1fr)); gap: 40px;">
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">Depression
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                Find the light again. Our advanced therapies help you break free from the cycle of depression and
                rediscover joy in life.
            </p>
            <a href="https://karmadocs.com/depression/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">Anxiety
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                You don't have to face it alone. We offer a comprehensive, compassionate path to reclaiming your peace
                of mind.
            </p>
            <a href="https://karmadocs.com/anxiety/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">PTSD
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                Healing from the past is possible. We provide a safe, supportive environment to help you process trauma
                and reclaim your life.
            </p>
            <a href="https://karmadocs.com/ptsd/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">ADHD
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                It's not just a childhood phase. Unlock your potential with our comprehensive testing and management
                strategies for adult ADHD.
            </p>
            <a href="https://karmadocs.com/adhd/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">Bipolar
                Disorder
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                Stabilize your mood and reclaim your life. Comprehensive care for Bipolar I, II, and Cyclothymia.
            </p>
            <a href="https://karmadocs.com/bipolar/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
        <div class="lux-hover-card"
            style="background: #ffffff; padding: 60px 45px; border-radius: 50px; border: 1px solid #E5E7EB;">
            <h3 style="font-size: 28px; font-weight: 900; color: var(--brand-purple); margin-bottom: 20px;">OCD
            </h3>
            <p style="color: #6B7280; font-size: 17px; line-height: 1.8; margin-bottom: 30px;">
                Reclaim your time and peace of mind. Evidence-based treatment including ERP and TMS therapy.
            </p>
            <a href="https://karmadocs.com/ocd/"
                style="font-weight: 900; color: var(--brand-purple); text-decoration: none; text-transform: uppercase; font-size: 13px; letter-spacing: 2.5px; border-bottom: 2px solid var(--brand-purple); padding-bottom: 5px;">Learn
                More +</a>
        </div>
    </div>
</section>

<!-- WHAT SETS US APART: ENHANCED DESIGN -->
<section
    style="padding: 120px 20px; background: #1a0f3c; background: linear-gradient(135deg, #1a0f3c 0%, var(--brand-purple) 100%); color: white; position: relative; overflow: hidden;">

    <!-- Design Elements: Blobs & Grids -->
    <div
        style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px); background-size: 30px 30px; opacity: 0.3; pointer-events: none;">
    </div>
    <div
        style="position: absolute; top: -10%; left: -5%; width: 500px; height: 500px; background: radial-gradient(circle, var(--brand-purple-light) 0%, transparent 70%); opacity: 0.2; filter: blur(60px); pointer-events: none;">
    </div>
    <div
        style="position: absolute; bottom: -10%; right: -5%; width: 600px; height: 600px; background: radial-gradient(circle, var(--brand-orange) 0%, transparent 70%); opacity: 0.15; filter: blur(80px); pointer-events: none;">
    </div>

    <!-- Floating Geometric Shapes -->
    <div
        style="position: absolute; top: 15%; right: 5%; width: 80px; height: 80px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); transform: rotate(45deg); border-radius: 15px; backdrop-filter: blur(5px); z-index: 1;">
    </div>
    <div
        style="position: absolute; bottom: 20%; left: 3%; width: 120px; height: 120px; background: rgba(244, 143, 18, 0.05); border: 1px dashed rgba(244, 143, 18, 0.2); transform: rotate(15deg); border-radius: 20px; z-index: 1;">
    </div>

    <div style="max-width: 1240px; margin: 0 auto; position: relative; z-index: 10;">
        <div style="text-align: center; margin-bottom: 80px;">
            <div style="display: flex; align-items: center; gap: 20px; justify-content: center; margin-bottom: 30px;">
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
                <span
                    style="text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-orange);">Beyond
                    Traditional Psychiatry</span>
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
            </div>
            <h2
                style="font-size: 48px; font-weight: 900; margin-bottom: 25px; letter-spacing: -0.02em; line-height: 1.1;">
                What Sets Us Apart <br />
                <span style="color: var(--brand-orange);">From Every Other Practice</span>
            </h2>
            <p
                style="font-size: 20px; color: rgba(255,255,255,0.8); max-width: 850px; margin: 0 auto; line-height: 1.8;">
                We don't believe in one-size-fits-all psychiatry. Every treatment plan is built around your unique
                biology, history, and goals using state-of-the-art mental healthcare protocols.</p>
        </div>

        <!-- STATS ROW -->
        <div
            style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; margin-bottom: 80px;">
            <div
                style="background: rgba(255,255,255,0.04); padding: 40px; border-radius: 30px; text-align: center; border: 1px solid rgba(255,255,255,0.06);">
                <div
                    style="font-size: 52px; font-weight: 900; color: var(--brand-orange); line-height: 1; margin-bottom: 12px;">
                    20+</div>
                <p
                    style="font-size: 13px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; margin: 0;">
                    Years Experience</p>
            </div>
            <div
                style="background: rgba(255,255,255,0.04); padding: 40px; border-radius: 30px; text-align: center; border: 1px solid rgba(255,255,255,0.06);">
                <div style="font-size: 52px; font-weight: 900; color: white; line-height: 1; margin-bottom: 12px;">3
                </div>
                <p
                    style="font-size: 13px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; margin: 0;">
                    Clinic Locations</p>
            </div>
            <div
                style="background: rgba(255,255,255,0.04); padding: 40px; border-radius: 30px; text-align: center; border: 1px solid rgba(255,255,255,0.06);">
                <div
                    style="font-size: 52px; font-weight: 900; color: var(--brand-orange); line-height: 1; margin-bottom: 12px;">
                    FDA</div>
                <p
                    style="font-size: 13px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; margin: 0;">
                    Cleared TMS</p>
            </div>
            <div
                style="background: rgba(255,255,255,0.04); padding: 40px; border-radius: 30px; text-align: center; border: 1px solid rgba(255,255,255,0.06);">
                <div style="font-size: 52px; font-weight: 900; color: white; line-height: 1; margin-bottom: 12px;">2x
                </div>
                <p
                    style="font-size: 13px; color: rgba(255,255,255,0.6); text-transform: uppercase; letter-spacing: 2px; font-weight: 800; margin: 0;">
                    Board Certified</p>
            </div>
        </div>

        <!-- VALUE PROPOSITIONS -->
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(350px, 1fr)); gap: 35px;">
            <div style="padding: 55px 45px; background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); border-radius: 40px; border: 1px solid rgba(255,255,255,0.1); transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.transform='translateY(-10px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div style="font-size: 40px; margin-bottom: 25px;">📊</div>
                <h3 style="font-size: 24px; font-weight: 900; color: white; margin-bottom: 20px;">Precision Brain
                    Mapping</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 17px; line-height: 1.8; margin: 0;">We use qEEG brain
                    mapping to visualize your brain's electrical activity, eliminating guesswork and targeting treatment
                    with data-driven accuracy.</p>
            </div>
            <div style="padding: 55px 45px; background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); border-radius: 40px; border: 1px solid rgba(255,255,255,0.1); transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.transform='translateY(-10px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div style="font-size: 40px; margin-bottom: 25px;">🥗</div>
                <h3 style="font-size: 24px; font-weight: 900; color: white; margin-bottom: 20px;">Integrative Philosophy
                </h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 17px; line-height: 1.8; margin: 0;">We combine
                    traditional medicine with nutritional psychiatry and mindfulness protocols to provide a true
                    whole-person recovery experience.</p>
            </div>
            <div style="padding: 55px 45px; background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); border-radius: 40px; border: 1px solid rgba(255,255,255,0.1); transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.1)'; this.style.transform='translateY(-10px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div style="font-size: 40px; margin-bottom: 25px;">🤝</div>
                <h3 style="font-size: 24px; font-weight: 900; color: white; margin-bottom: 20px;">Stigma-Free Care</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 17px; line-height: 1.8; margin: 0;">Mental healthcare
                    should be accessible and free of judgment. We treat every patient with genuine warmth and respect
                    from day one.</p>
            </div>
        </div>
    </div>
</section>

<!-- MEET DR. SUNDER -->
<section style="padding: 120px 20px; background: #ffffff;">
    <div
        style="max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 80px; align-items: center;">
        <div>
            <img src="<?php echo get_template_directory_uri(); ?>/assets/4990c7a6-07b7-48c2-9a5f-cd188d2ad944.png"
                alt="Dr. Keerthy Sunder, MD — Founder, <a href='https://karmadocs.com/' style='color: var(--brand-orange); text-decoration: none; font-weight: 700;'>Karma Doctors & Associates</a>"
                style="width: 100%; height: auto; border-radius: 40px; display: block; box-shadow: 0 20px 50px rgba(0,0,0,0.15);" />
        </div>
        <div>
            <div style="display: flex; align-items: center; gap: 20px; margin-bottom: 30px;">
                <div style="height: 2px; width: 60px; background: var(--brand-purple);"></div>
                <span
                    style="text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-purple);">Meet
                    Our Founder</span>
            </div>
            <h2
                style="font-size: 42px; font-weight: 900; color: var(--brand-dark); line-height: 1.1; margin-bottom: 20px; letter-spacing: -0.02em;">
                Dr. Keerthy Sunder, <span style="color: var(--brand-purple);">MD</span></h2>
            <p
                style="font-size: 18px; font-weight: 700; color: var(--brand-orange); margin-bottom: 30px; letter-spacing: 0.5px;">
                Double Board-Certified Psychiatrist</p>
            <p style="font-size: 18px; color: #4B5563; line-height: 1.9; margin-bottom: 25px;">
                With over two decades of clinical experience, Dr. Sunder stands at the forefront of modern mental
                healthcare. He is a pioneer in Integrated Psychiatry, uniquely combining traditional medical excellence
                with mindfulness protocols, nutritional psychiatry, and advanced non-invasive technologies like TMS.
            </p>
            <p style="font-size: 18px; color: #4B5563; line-height: 1.9; margin-bottom: 35px;">
                His mission is to de-stigmatize mental health and provide accessible, effective treatments that empower
                patients to take control of their lives. Every Banning patient benefits from his philosophy: <em
                    style="color: var(--brand-purple); font-weight: 700;">"We treat the person, not just the
                    diagnosis."</em>
            </p>

            <!-- Credentials -->
            <div style="display: flex; flex-wrap: wrap; gap: 12px; margin-bottom: 35px;">
                <span
                    style="background: rgba(96, 49, 119, 0.08); color: var(--brand-purple); padding: 10px 22px; border-radius: 100px; font-size: 14px; font-weight: 700;">Board
                    Certified</span>
                <span
                    style="background: rgba(244, 143, 18, 0.08); color: var(--brand-orange); padding: 10px 22px; border-radius: 100px; font-size: 14px; font-weight: 700;">TMS
                    Specialist</span>
                <span
                    style="background: rgba(96, 49, 119, 0.08); color: var(--brand-purple); padding: 10px 22px; border-radius: 100px; font-size: 14px; font-weight: 700;">Integrative
                    Medicine</span>
                <span
                    style="background: rgba(244, 143, 18, 0.08); color: var(--brand-orange); padding: 10px 22px; border-radius: 100px; font-size: 14px; font-weight: 700;">20+
                    Years Experience</span>
            </div>

            <a href="https://karmadocs.com/about-us/"
                style="display: inline-block; background: var(--brand-purple); color: white; padding: 20px 50px; border-radius: 100px; text-decoration: none; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; font-size: 14px; box-shadow: 0 15px 40px rgba(96, 49, 119, 0.3); transition: transform 0.3s ease;">
                Learn More About Dr. Sunder
            </a>
        </div>
    </div>
</section>

<!-- OUR SERVICES -->
<section
    style="padding: 120px 20px; background: #1a0f3c; background: linear-gradient(135deg, #1a0f3c 0%, var(--brand-purple) 100%); color: white; position: relative; overflow: hidden;">

    <!-- Design Elements -->
    <div
        style="position: absolute; top: 0; left: 0; right: 0; bottom: 0; background-image: radial-gradient(rgba(255,255,255,0.05) 1px, transparent 1px); background-size: 30px 30px; opacity: 0.3; pointer-events: none;">
    </div>
    <div
        style="position: absolute; top: 10%; right: -10%; width: 500px; height: 500px; background: radial-gradient(circle, var(--brand-orange) 0%, transparent 70%); opacity: 0.12; filter: blur(60px); pointer-events: none;">
    </div>
    <div
        style="position: absolute; bottom: 10%; left: -10%; width: 500px; height: 500px; background: radial-gradient(circle, var(--brand-purple-light) 0%, transparent 70%); opacity: 0.15; filter: blur(60px); pointer-events: none;">
    </div>

    <!-- Floating Shapes -->
    <div
        style="position: absolute; top: 20%; left: 5%; width: 60px; height: 60px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.1); transform: rotate(15deg); border-radius: 12px; backdrop-filter: blur(5px); z-index: 1;">
    </div>
    <div
        style="position: absolute; bottom: 15%; right: 7%; width: 90px; height: 90px; background: rgba(244, 143, 18, 0.04); border: 1px dashed rgba(244, 143, 18, 0.15); transform: rotate(-10deg); border-radius: 18px; z-index: 1;">
    </div>

    <div style="max-width: 1100px; margin: 0 auto; position: relative; z-index: 10;">
        <div style="text-align: center; margin-bottom: 80px;">
            <div style="display: flex; align-items: center; gap: 20px; justify-content: center; margin-bottom: 30px;">
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
                <span
                    style="text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-orange);">What
                    We Offer</span>
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
            </div>
            <h2 style="font-size: 44px; font-weight: 900; margin-bottom: 25px; letter-spacing: -0.02em;">
                Our Services</h2>
            <p
                style="font-size: 20px; color: rgba(255,255,255,0.8); max-width: 700px; margin: 0 auto; line-height: 1.7;">
                A full spectrum of psychiatric services designed to treat the root cause, not just the symptoms.</p>
        </div>

        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 30px;">
            <div style="background: rgba(255,255,255,0.06); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); padding: 45px 35px; border-radius: 30px; transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.12)'; this.style.transform='translateY(-8px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div
                    style="width: 60px; height: 60px; background: var(--brand-orange); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin-bottom: 25px; font-size: 28px;">
                    🧠</div>
                <h3 style="font-size: 22px; font-weight: 900; margin-bottom: 15px;">TMS Therapy</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; line-height: 1.8; margin-bottom: 20px;">
                    FDA-cleared, drug-free magnetic stimulation personalized to your brain map for lasting relief.</p>
                <a href="https://karmadocs.com/tms-therapy/"
                    style="color: var(--brand-orange); font-weight: 800; text-decoration: none; font-size: 13px; text-transform: uppercase; letter-spacing: 2px;">Learn
                    More →</a>
            </div>
            <div style="background: rgba(255,255,255,0.06); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); padding: 45px 35px; border-radius: 30px; transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.12)'; this.style.transform='translateY(-8px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div
                    style="width: 60px; height: 60px; background: var(--brand-purple-light); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin-bottom: 25px; font-size: 28px;">
                    💊</div>
                <h3 style="font-size: 22px; font-weight: 900; margin-bottom: 15px;">Medication Management</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; line-height: 1.8; margin-bottom: 20px;">
                    Metabolic-aware prescribing with ongoing monitoring to optimize effectiveness and minimize side
                    effects.</p>
                <a href="https://karmadocs.com/medication-management/"
                    style="color: var(--brand-orange); font-weight: 800; text-decoration: none; font-size: 13px; text-transform: uppercase; letter-spacing: 2px;">Learn
                    More →</a>
            </div>
            <div style="background: rgba(255,255,255,0.06); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); padding: 45px 35px; border-radius: 30px; transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.12)'; this.style.transform='translateY(-8px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div
                    style="width: 60px; height: 60px; background: var(--brand-orange); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin-bottom: 25px; font-size: 28px;">
                    📊</div>
                <h3 style="font-size: 22px; font-weight: 900; margin-bottom: 15px;">qEEG Brain Mapping</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; line-height: 1.8; margin-bottom: 20px;">
                    Advanced neuroimaging that reveals your brain's unique patterns, guiding precision treatment
                    decisions.</p>
                <a href="https://karmadocs.com/qeeg-brain-mapping/"
                    style="color: var(--brand-orange); font-weight: 800; text-decoration: none; font-size: 13px; text-transform: uppercase; letter-spacing: 2px;">Learn
                    More →</a>
            </div>
            <div style="background: rgba(255,255,255,0.06); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.1); padding: 45px 35px; border-radius: 30px; transition: all 0.4s ease;"
                onmouseover="this.style.background='rgba(255,255,255,0.12)'; this.style.transform='translateY(-8px)';"
                onmouseout="this.style.background='rgba(255,255,255,0.06)'; this.style.transform='translateY(0)';">
                <div
                    style="width: 60px; height: 60px; background: var(--brand-purple-light); border-radius: 20px; display: flex; align-items: center; justify-content: center; margin-bottom: 25px; font-size: 28px;">
                    🌿</div>
                <h3 style="font-size: 22px; font-weight: 900; margin-bottom: 15px;">Integrative Psychiatry</h3>
                <p style="color: rgba(255,255,255,0.7); font-size: 15px; line-height: 1.8; margin-bottom: 20px;">
                    Combining nutrition, mindfulness, and clinical interventions for holistic mental health
                    transformation.</p>
                <a href="https://karmadocs.com/about-us/"
                    style="color: var(--brand-orange); font-weight: 800; text-decoration: none; font-size: 13px; text-transform: uppercase; letter-spacing: 2px;">Learn
                    More →</a>
            </div>
        </div>
    </div>
</section>


<!-- ABOUT Banning COMMUNITY SECTION -->
<section style='padding: 120px 20px; background: #ffffff;'>
<div style='max-width: 1200px; margin: 0 auto; display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 80px; align-items: center;'>
<div><div style='display: flex; align-items: center; gap: 20px; margin-bottom: 30px;'><div style='height: 2px; width: 60px; background: var(--brand-orange);'></div><span style='text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-orange);'>Serving Banning</span></div>
<h2 style='font-size: 42px; font-weight: 900; color: var(--brand-dark); line-height: 1.1; margin-bottom: 30px; letter-spacing: -0.02em;'>Proudly Serving the <br /><span style='color: var(--brand-purple);'>Banning Community</span></h2>
<p style='font-size: 18px; color: #4B5563; line-height: 1.9; margin-bottom: 25px;'>The energy of Banning is unmistakable, characterized by a spirit of innovation and a deep appreciation for top-tier quality of life.</p>
<p style='font-size: 18px; color: #4B5563; line-height: 1.9; margin-bottom: 25px;'>We recognize that Banning is a fast-paced environment where mental resilience is key. Our solutions are tailored specifically for the residents of Banning, focusing on long-term recovery.</p>
<p style='font-size: 18px; color: #4B5563; line-height: 1.9;'>From the heart of Banning to its furthest boundaries, our mission remains the same: to provide the highest standard of psychiatric intervention to every person who calls Banning home.</p></div>
<div><div style='background: var(--brand-gray); padding: 35px; border-radius: 25px; border: 1px solid #E5E7EB; margin-bottom: 20px;'><h4 style='font-size: 20px; font-weight: 900; color: var(--brand-purple); margin-bottom: 12px;'>Regional Mental Health Hub</h4><p style='color: #4B5563; font-size: 16px; line-height: 1.7;'>Three strategically located clinics ensure no resident is more than a short drive from expert care.</p></div></div></div></section>
<!-- PATIENT TESTIMONIALS SLIDER -->
<section
    style="padding: 120px 20px; background: linear-gradient(135deg, #1a0f3c 0%, var(--brand-purple) 100%); color: white;">
    <div style="max-width: 900px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 60px;">
            <div style="display: flex; align-items: center; gap: 20px; justify-content: center; margin-bottom: 30px;">
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
                <span
                    style="text-transform: uppercase; font-weight: 800; letter-spacing: 4px; font-size: 13px; color: var(--brand-orange);">Stories
                    of Hope</span>
                <div style="height: 2px; width: 60px; background: var(--brand-orange);"></div>
            </div>
            <h2 style="font-size: 44px; font-weight: 900; margin-bottom: 25px; letter-spacing: -0.02em;">
                What Our Patients Say</h2>
            <p
                style="font-size: 20px; color: rgba(255,255,255,0.8); max-width: 700px; margin: 0 auto; line-height: 1.7;">
                Real
                stories from real patients who found clarity, relief, and hope.</p>
        </div>

        <!-- Slider Container -->
        <div id="testimonialSlider" style="position: relative;" onmouseenter="clearInterval(sliderInterval)"
            onmouseleave="sliderInterval = setInterval(nextSlide, 5000)">

            <!-- Slides Wrapper -->
            <div style="overflow: hidden; border-radius: 30px;">
                <div id="slidesContainer" style="position: relative; min-height: 320px;">

                    <!-- Slide 1 -->
                    <div class="testimonial-slide"
                        style="position: absolute; top: 0; left: 0; width: 100%; opacity: 1; transition: opacity 0.6s ease;">
                        <div
                            style="background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); padding: 55px 50px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.1); position: relative;">
                            <div
                                style="font-size: 80px; color: var(--brand-orange); opacity: 0.2; position: absolute; top: 15px; left: 40px; font-family: Georgia, serif; line-height: 1;">
                                "</div>
                            <div style="display: flex; gap: 4px; margin-bottom: 20px;">
                                <span style="color: var(--brand-orange); font-size: 20px;">&#9733;</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">&#9733;</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">&#9733;</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">&#9733;</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">&#9733;</span>
                            </div>
                            <p
                                style="color: rgba(255,255,255,0.9); font-size: 19px; line-height: 1.9; margin-bottom: 30px; font-style: italic;">
                                "Living with chronic depression in the desert heat felt unbearable. The TMS therapy at Karma Doctors gave me my life back — the staff even helped me set up transportation from my Avenue 48 home. Incredible care."
                            </p>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div
                                    style="width: 55px; height: 55px; background: var(--brand-purple-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 22px;">
                                    D</div>
                                <div>
                                    <p style="font-weight: 800; color: white; font-size: 17px; margin: 0;">David K.</p>
                                    <p style="color: rgba(255,255,255,0.5); font-size: 14px; margin: 0;">Banning Resident
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Slide 2 -->
                    <div class="testimonial-slide"
                        style="position: absolute; top: 0; left: 0; width: 100%; opacity: 0; transition: opacity 0.6s ease;">
                        <div
                            style="background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); padding: 55px 50px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.1); position: relative;">
                            <div
                                style="font-size: 80px; color: var(--brand-orange); opacity: 0.2; position: absolute; top: 15px; left: 40px; font-family: Georgia, serif; line-height: 1;">
                                "</div>
                            <div style="display: flex; gap: 4px; margin-bottom: 20px;">
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                            </div>
                            <p
                                style="color: rgba(255,255,255,0.9); font-size: 19px; line-height: 1.9; margin-bottom: 30px; font-style: italic;">
                                "The brain mapping technology helped me finally understand my anxiety triggers. Dr. Sunder's personalized protocol addressed issues other doctors missed entirely. My quality of life has improved dramatically."
                            </p>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div
                                    style="width: 55px; height: 55px; background: var(--brand-orange); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 22px;">
                                    G</div>
                                <div>
                                    <p style="font-weight: 800; color: white; font-size: 17px; margin: 0;">George M.</p>
                                    <p style="color: rgba(255,255,255,0.5); font-size: 14px; margin: 0;">Banning Area Resident</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Slide 3 -->
                    <div class="testimonial-slide"
                        style="position: absolute; top: 0; left: 0; width: 100%; opacity: 0; transition: opacity 0.6s ease;">
                        <div
                            style="background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); padding: 55px 50px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.1); position: relative;">
                            <div
                                style="font-size: 80px; color: var(--brand-orange); opacity: 0.2; position: absolute; top: 15px; left: 40px; font-family: Georgia, serif; line-height: 1;">
                                "</div>
                            <div style="display: flex; gap: 4px; margin-bottom: 20px;">
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                            </div>
                            <p
                                style="color: rgba(255,255,255,0.9); font-size: 19px; line-height: 1.9; margin-bottom: 30px; font-style: italic;">
                                "As a former Army nurse, I've seen trauma from both sides. The Banning clinic understands veteran mental health in ways that civilian providers simply cannot. Helped me process decades of unresolved issues."
                            </p>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div
                                    style="width: 55px; height: 55px; background: var(--brand-purple-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 22px;">
                                    P</div>
                                <div>
                                    <p style="font-weight: 800; color: white; font-size: 17px; margin: 0;">Patricia H.</p>
                                    <p style="color: rgba(255,255,255,0.5); font-size: 14px; margin: 0;">Banning Veteran</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Slide 4 -->
                    <div class="testimonial-slide"
                        style="position: absolute; top: 0; left: 0; width: 100%; opacity: 0; transition: opacity 0.6s ease;">
                        <div
                            style="background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); padding: 55px 50px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.1); position: relative;">
                            <div
                                style="font-size: 80px; color: var(--brand-orange); opacity: 0.2; position: absolute; top: 15px; left: 40px; font-family: Georgia, serif; line-height: 1;">
                                "</div>
                            <div style="display: flex; gap: 4px; margin-bottom: 20px;">
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                            </div>
                            <p
                                style="color: rgba(255,255,255,0.9); font-size: 19px; line-height: 1.9; margin-bottom: 30px; font-style: italic;">
                                "The comprehensive approach at Karma Doctors including nutritional support and mindfulness training helped me achieve stability I couldn't find with medication alone. Truly transformative for my mental health."
                            </p>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div
                                    style="width: 55px; height: 55px; background: var(--brand-orange); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 22px;">
                                    N</div>
                                <div>
                                    <p style="font-weight: 800; color: white; font-size: 17px; margin: 0;">Nancy K.</p>
                                    <p style="color: rgba(255,255,255,0.5); font-size: 14px; margin: 0;">Cabazon Area Resident</p>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Slide 5 -->
                    <div class="testimonial-slide"
                        style="position: absolute; top: 0; left: 0; width: 100%; opacity: 0; transition: opacity 0.6s ease;">
                        <div
                            style="background: rgba(255,255,255,0.06); backdrop-filter: blur(15px); padding: 55px 50px; border-radius: 30px; border: 1px solid rgba(255,255,255,0.1); position: relative;">
                            <div
                                style="font-size: 80px; color: var(--brand-orange); opacity: 0.2; position: absolute; top: 15px; left: 40px; font-family: Georgia, serif; line-height: 1;">
                                "</div>
                            <div style="display: flex; gap: 4px; margin-bottom: 20px;">
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                                <span style="color: var(--brand-orange); font-size: 20px;">★</span>
                            </div>
                            <p
                                style="color: rgba(255,255,255,0.9); font-size: 19px; line-height: 1.9; margin-bottom: 30px; font-style: italic;">
                                "When my teenager was diagnosed with ADHD, we were lost. Dr. Sunder's family therapy approach and careful medication management turned our family life around. Our son is now thriving in college."
                            </p>
                            <div style="display: flex; align-items: center; gap: 15px;">
                                <div
                                    style="width: 55px; height: 55px; background: var(--brand-purple-light); border-radius: 50%; display: flex; align-items: center; justify-content: center; color: white; font-weight: 900; font-size: 22px;">
                                    W</div>
                                <div>
                                    <p style="font-weight: 800; color: white; font-size: 17px; margin: 0;">William C.</p>
                                    <p style="color: rgba(255,255,255,0.5); font-size: 14px; margin: 0;">Banning Area Parent</p>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

            <!-- Navigation Arrows -->
            <button onclick="prevSlide()" aria-label="Previous testimonial"
                style="position: absolute; top: 50%; left: -25px; transform: translateY(-50%); width: 55px; height: 55px; border-radius: 50%; border: none; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); color: white; font-size: 22px; cursor: pointer; border: 1px solid rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; z-index: 5;"
                onmouseover="this.style.background='var(--brand-orange)'; this.style.borderColor='var(--brand-orange)';"
                onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                ‹
            </button>
            <button onclick="nextSlide()" aria-label="Next testimonial"
                style="position: absolute; top: 50%; right: -25px; transform: translateY(-50%); width: 55px; height: 55px; border-radius: 50%; border: none; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); color: white; font-size: 22px; cursor: pointer; border: 1px solid rgba(255,255,255,0.2); display: flex; align-items: center; justify-content: center; transition: all 0.3s ease; z-index: 5;"
                onmouseover="this.style.background='var(--brand-orange)'; this.style.borderColor='var(--brand-orange)';"
                onmouseout="this.style.background='rgba(255,255,255,0.1)'; this.style.borderColor='rgba(255,255,255,0.2)';">
                ›
            </button>
        </div>

        <!-- Dots Navigation -->
        <div id="sliderDots" style="display: flex; justify-content: center; gap: 12px; margin-top: 40px;"></div>
    </div>
</section>

<script>
    (function () {
        var currentSlide = 0;
        var slides = document.querySelectorAll('.testimonial-slide');
        var totalSlides = slides.length;
        var dotsContainer = document.getElementById('sliderDots');

        // Create dots
        for (var i = 0; i < totalSlides; i++) {
            var dot = document.createElement('button');
            dot.setAttribute('aria-label', 'Go to slide ' + (i + 1));
            dot.style.cssText = 'width: 12px; height: 12px; border-radius: 50%; border: none; cursor: pointer; transition: all 0.3s ease; padding: 0;';
            dot.style.background = i === 0 ? 'var(--brand-purple)' : '#D1D5DB';
            dot.style.transform = i === 0 ? 'scale(1.3)' : 'scale(1)';
            (function (index) {
                dot.addEventListener('click', function () { goToSlide(index); });
            })(i);
            dotsContainer.appendChild(dot);
        }

        // Set initial container height
        function setContainerHeight() {
            var container = document.getElementById('slidesContainer');
            var activeSlide = slides[currentSlide];
            container.style.minHeight = activeSlide.offsetHeight + 'px';
        }
        setContainerHeight();
        window.addEventListener('resize', setContainerHeight);

        window.goToSlide = function (index) {
            slides[currentSlide].style.opacity = '0';
            var dots = dotsContainer.children;
            dots[currentSlide].style.background = '#D1D5DB';
            dots[currentSlide].style.transform = 'scale(1)';

            currentSlide = index;

            slides[currentSlide].style.opacity = '1';
            dots[currentSlide].style.background = 'var(--brand-purple)';
            dots[currentSlide].style.transform = 'scale(1.3)';
            setContainerHeight();
        };

        window.nextSlide = function () {
            goToSlide((currentSlide + 1) % totalSlides);
        };

        window.prevSlide = function () {
            goToSlide((currentSlide - 1 + totalSlides) % totalSlides);
        };

        window.sliderInterval = setInterval(nextSlide, 5000);
    })();
</script>

<!-- FAQ SECTION -->
<section style="padding: 120px 20px; background: #fafafa;">
    <div style="max-width: 1200px; margin: 0 auto;">
        <div class="faq-grid">
            <!-- Left Info -->
            <div>
                <span
                    style="color: var(--brand-orange); font-weight: 800; text-transform: uppercase; letter-spacing: 3px; font-size: 14px; display: block; margin-bottom: 20px;">FAQ</span>
                <h2
                    style="font-size: 48px; font-weight: 900; color: var(--brand-dark); margin-bottom: 30px; letter-spacing: -0.02em; line-height: 1.1;">
                    Frequently Asked Questions</h2>
                <p style="font-size: 19px; color: #6B7280; line-height: 1.8; max-width: 450px;">
                    We compiled a list of answers to address your most pressing questions regarding our psychiatric
                    treatments, insurance, and the care we provide in the Banning area.
                </p>
            </div>

            <!-- Right Accordion -->
            <div>
                <details class="faq-item">
                    <summary>Why see a psychiatrist near Banning instead of a general doctor?</summary>
                    <div class="faq-answer">
                        <p>Psychiatrists are medical doctors who specialize exclusively in mental health. Unlike general
                            practitioners, we offer advanced diagnostic tools such as brain mapping (qEEG), Personalized
                            Repetitive TMS (PrTMS), and metabolic-aware medication management. At Karma Doctors &
                            Associates,
                            our board-certified psychiatrists provide a depth of expertise in complex conditions like
                            treatment-resistant depression, PTSD, and bipolar disorder that goes far beyond what a
                            primary care
                            setting can deliver.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>How far is Karma Doctors from Banning?</summary>
                    <div class="faq-answer">
                        <p>Our nearest location in Rancho Mirage is just a short 15-minute drive from central Banning via
                            Highway
                            111. We also have offices in Palm Springs and Twentynine Palms, giving Banning residents
                            multiple
                            convenient options for world-class psychiatric care without a long commute to a major
                            metropolitan
                            hub.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>What is TMS therapy and is it available near Banning?</summary>
                    <div class="faq-answer">
                        <p>Transcranial Magnetic Stimulation (TMS) is an FDA-cleared, non-invasive treatment that uses
                            magnetic
                            pulses to stimulate specific areas of the brain. It is especially effective for patients
                            with
                            treatment-resistant depression, anxiety, and OCD. At Karma Doctors, we offer Personalized
                            Repetitive
                            TMS (PrTMS), which uses your unique brain map (qEEG) to tailor each session. This advanced
                            therapy
                            is available at our Rancho Mirage and Palm Springs locations, both easily accessible from
                            Banning.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>Do you accept insurance for psychiatric services?</summary>
                    <div class="faq-answer">
                        <p>Yes, <a href='https://karmadocs.com/' style='color: var(--brand-orange); text-decoration: none; font-weight: 700;'>Karma Doctors & Associates</a> accepts most major insurance plans. We recommend contacting
                            our
                            office directly at (951) 297-8375 or visiting our website to verify your specific coverage.
                            Our team
                            will work with you to maximize your benefits so you can focus on your treatment and recovery
                            without
                            unnecessary financial stress.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>Do you offer telehealth appointments for Banning residents?</summary>
                    <div class="faq-answer">
                        <p>Absolutely. We offer secure, HIPAA-compliant telehealth appointments for patients who prefer
                            the
                            convenience of remote consultations. This is an excellent option for follow-up visits,
                            medication
                            management, and ongoing therapy sessions. Telehealth allows Banning residents to connect with
                            our
                            board-certified psychiatrists from the comfort of their home.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>What should I expect during my first visit?</summary>
                    <div class="faq-answer">
                        <p>Your first appointment is a comprehensive psychiatric evaluation lasting approximately 60
                            minutes.
                            Dr. Sunder or a member of our clinical team will review your medical history, discuss your
                            symptoms
                            and goals, and may recommend diagnostic assessments such as a qEEG brain map. From there, we
                            create
                            a fully personalized treatment plan that may include medication management, TMS therapy,
                            lifestyle
                            modifications, or a combination of integrative approaches tailored to your needs.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>Does Karma Doctors accept insurance for TMS therapy?</summary>
                    <div class="faq-answer">
                        <p>Yes, Karma Doctors & Associates works with most major insurance providers for TMS therapy.
                        Coverage varies by plan, so we recommend calling (951) 297-8375 to verify your specific benefits for PrTMS treatment in Banning.
                        Our team will help you understand your coverage and explore financing options if needed.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>What is the difference between a psychiatrist and a therapist?</summary>
                    <div class="faq-answer">
                        <p>Psychiatrists are medical doctors (MDs) who can prescribe medication and offer medical treatments like TMS.
                        Therapists (LCSWs, LMFTs, psychologists) provide talk therapy but cannot prescribe medication.
                        At Karma Doctors, our psychiatrists integrate both approaches for comprehensive mental health care in Banning.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>Are you currently accepting new patients for anxiety therapy?</summary>
                    <div class="faq-answer">
                        <p>Yes, Karma Doctors & Associates is currently accepting new patients for anxiety treatment in Banning.
                        We offer both in-person and telehealth appointments, including medication management and TMS therapy.
                        Contact us at (951) 297-8375 to schedule your appointment.</p>
                    </div>
                </details>

                <details class="faq-item">
                    <summary>How long does TMS therapy take to work?</summary>
                    <div class="faq-answer">
                        <p>Most patients begin noticing improvements within 2-4 weeks of starting TMS therapy.
                        A full course typically involves 20-30 sessions over 4-6 weeks at our nearby locations accessible from Banning.
                        Results vary based on the condition being treated and individual brain chemistry, but many patients report significant improvement by their second week of treatment.</p>
                    </div>
                </details>
            </div>
        </div>
    </div>
</section>


<!-- FINAL CALL TO ACTION: REDESIGNED -->
<section style="padding: 100px 20px; background: #ffffff;">
    <div
        style="max-width: 1200px; margin: 0 auto; position: relative; overflow: hidden; border-radius: 40px; background: linear-gradient(135deg, #1a0f3c 0%, var(--brand-purple) 100%); padding: 120px 40px; text-align: center; box-shadow: 0 40px 100px rgba(26, 15, 60, 0.3);">

        <!-- Animated Background Shapes -->
        <div
            style="position: absolute; top: 10%; left: -5%; width: 250px; height: 250px; background: linear-gradient(135deg, rgba(255,255,255,0.1) 0%, transparent 100%); transform: rotate(45deg); border-radius: 20px; pointer-events: none; z-index: 1;">
        </div>
        <div
            style="position: absolute; bottom: -10%; right: -5%; width: 300px; height: 300px; background: linear-gradient(135deg, var(--brand-orange) 0%, transparent 100%); opacity: 0.15; transform: rotate(45deg); border-radius: 40px; pointer-events: none; z-index: 1;">
        </div>
        <div
            style="position: absolute; top: 20%; right: 10%; width: 60px; height: 60px; background: rgba(255,255,255,0.1); backdrop-filter: blur(10px); transform: rotate(45deg); border-radius: 10px; pointer-events: none; z-index: 1;">
        </div>
        <div
            style="position: absolute; bottom: 20%; left: 15%; width: 80px; height: 80px; background: rgba(244, 143, 18, 0.2); transform: rotate(45deg); border-radius: 15px; pointer-events: none; z-index: 1;">
        </div>

        <div style="position: relative; z-index: 10;">
            <h2 style='font-size: clamp(2.5rem, 5vw, 3.8rem); font-weight: 900; color: white; margin-bottom: 25px; letter-spacing: -0.04em; line-height: 1.1;'>Clinical Hope for Lasting Recovery</h2>
            <p
                style="font-size: 20px; color: rgba(255,255,255,0.8); max-width: 650px; margin: 0 auto 50px; line-height: 1.6; font-weight: 300;">
                Take the first step toward a transformative recovery with our data-driven, compassionate psychiatric
                care near Banning.
            </p>

            <div style="display: flex; gap: 20px; justify-content: center; flex-wrap: wrap; margin-bottom: 30px;">
                <a href="https://karmadocs.com/contact/"
                    style="background: var(--brand-orange); color: white; padding: 22px 55px; border-radius: 100px; text-decoration: none; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; font-size: 14px; box-shadow: 0 15px 40px rgba(244, 143, 18, 0.4); transition: transform 0.3s ease;">
                    Book Your Evaluation
                </a>
                <a href="tel:9512978375"
                    style="background: rgba(255, 255, 255, 0.05); color: white; padding: 20px 50px; border-radius: 100px; text-decoration: none; font-weight: 900; text-transform: uppercase; letter-spacing: 2px; font-size: 14px; border: 1px solid rgba(255,255,255,0.2); transition: all 0.3s ease; backdrop-filter: blur(10px);">
                    Contact Our Team
                </a>
            </div>

        </div>
    </div>
</section>

</main>
<?php
get_footer();
?>